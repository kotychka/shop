<?php

return array(
	"db" => array(
		"user" => "artem",
		"pass" => "123"
	)
)