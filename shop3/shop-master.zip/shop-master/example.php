<?php

echo "^)\n";
