<?php

class Notebook implements ProductInterface
{
	public function price()
	{
		return 0;
	}

	public function title()
	{
		return "";
	}

	public function img() 
	{
		return "";
	}
}