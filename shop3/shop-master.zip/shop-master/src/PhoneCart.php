<?php

include_once __DIR__."/Phone.php";

class PhoneCart extends Phone
{
	public $qnt = 1;
}