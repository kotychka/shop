<?php

interface ProductInterface
{
	public function price();
	public function title();
	public function img();
}