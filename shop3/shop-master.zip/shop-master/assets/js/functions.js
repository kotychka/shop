function message (fname, lname) {
	return "Hello " + fname + " " + lname;

	// return m;
}

fname = "Artem"
lname = "Kovardin"

var result = message(fname, lname)

// console.log(result)

// hello("Artem", "Kovardin")
// hello("Petr", "Ermolaev")

// var b = "Hi!"

// function message () {
// 	var m = "Hello!"
// 	console.log(m)
// 	console.log(b)

// 	var f = function() {
// 		var c = "privet";
// 		console.log(m)
// 	};

// 	console.log(c)

// 	f()
// }

// message()

// console.log(m)