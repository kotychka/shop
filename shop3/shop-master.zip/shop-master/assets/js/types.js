var num = 123;
var str = "";
var bl = true;
var nl = null;
var undf;
var obj = {};
var func = function(){};

console.log(typeof(num))
console.log(typeof(str))
console.log(typeof(bl))
console.log(typeof(nl))
console.log(typeof(undf))
console.log(typeof(obj))
console.log(typeof(func))